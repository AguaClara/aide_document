# Aide Document

# Team Lead
Matan Presberg(mgp64)

## Team Members:
Karan Newatia (kn348)

Oliver Leung (oal22)

Yilin Lu (yl668)

## Semester Goals
The Aide Document subteam's goals are to use Jinja2 to parse YAML input and convert it to markdown/pdf.

## Links to Reports and Presentations


